import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

final class RPCServerSqrt {
    DatagramSocket ds;
    DatagramPacket dp;

    String str, methodName;

    double num, result;

    RPCServerSqrt() {
        try {

            final int PORT = 1200;

            ds = new DatagramSocket(PORT);

            byte b[] = new byte[4096];
            while (true) {
                dp = new DatagramPacket(b, b.length);
                ds.receive(dp);

                str = new String(dp.getData(), 0, dp.getLength());

                if (str.equalsIgnoreCase("q")) {
                    System.exit(1);
                }

                StringTokenizer tokenizer = new StringTokenizer(str, " ");

                while (tokenizer.hasMoreTokens()) {
                    String token = tokenizer.nextToken();
                    methodName = token.toLowerCase();
                    num = Integer.parseInt(tokenizer.nextToken());
                }
                System.out.println(str);

                InetAddress address = InetAddress.getLocalHost();
                final int DEST_PORT = 1300;

                switch (methodName) {
                    case "square":
                        result = num * num;
                        break;
                    case "squareroot":
                        result = Math.sqrt(num);
                        break;
                    case "cube":
                        result = num * num * num;
                        break;
                    case "cuberoot":
                        result = Math.cbrt(num);
                        break;
                }

                byte resultBytes[] = Double.toString(result).getBytes();
                DatagramSocket datagramSocket = new DatagramSocket();

                DatagramPacket datagramPacket = new DatagramPacket(resultBytes, resultBytes.length, address, DEST_PORT);

                System.out.println("Result: " + result + "\n");
                datagramSocket.send(datagramPacket);
            }
        }

        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        new RPCServerSqrt();
    }
}
