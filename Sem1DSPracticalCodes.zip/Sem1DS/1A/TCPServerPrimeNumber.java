import java.net.*;
import java.io.*;

public class TCPServerPrimeNumber {
    public static void main(String[] args) {
        try {
            final int PORT = 8001;
            ServerSocket ss = new ServerSocket(PORT);
            System.out.println("Server Started on port " + PORT);
            Socket s = ss.accept();
            DataInputStream dataInput = new DataInputStream(s.getInputStream());
            int x = dataInput.readInt();
            DataOutputStream dataOutput = new DataOutputStream(s.getOutputStream());
            int y = x / 2;

            if (x == 1) {
                dataOutput.writeUTF(x + " is neither Prime nor composite");
                System.exit(0);
            }

            boolean isPrime = false;
            for (int i = 2; i <= y; i++) {
                if (x % i == 0) {
                    isPrime = true;
                    break;
                }
            }

            if (isPrime) {
                dataOutput.writeUTF(x + " is not a Prime Number");
            } else {
                dataOutput.writeUTF(x + " is a Prime Number");
            }
            ss.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
