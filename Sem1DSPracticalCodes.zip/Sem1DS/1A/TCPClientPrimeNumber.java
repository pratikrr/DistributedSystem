import java.net.*;
import java.io.*;

public class TCPClientPrimeNumber {
    public static void main(String[] args) {
        try {
            final int PORT = 8001;
            Socket s = new Socket("Localhost", PORT);
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter a number: ");
            int x = Integer.parseInt(input.readLine());
            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            out.writeInt(x);
            DataInputStream in = new DataInputStream(s.getInputStream());
            System.out.println(in.readUTF());
            s.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
